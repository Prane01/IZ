#include <iostream>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
using namespace std;

int ITK_user_main(int arg, char* args[]) {

	int iFail = 0;
	char* cError = NULL;
	tag_t tItem = NULLTAG;
	tag_t tRevision = NULLTAG;

	iFail = ITK_init_module("izn", "izn", "dba");
	if (iFail == ITK_ok) {
		cout << "\n\n Login Successful..\n";
		iFail = ITEM_create_item("152440", "ITK Test", "Item", "A", &tItem, &tRevision);
		if (iFail == ITK_ok) {
			cout << "\n\n Item Created Successfully..\n";
			iFail = ITEM_save_item(tItem);
			if (iFail == ITK_ok) {
				cout << "\n\n Item Saved Successfully..\n";
			}
			else {
				EMH_ask_error_text(iFail, &cError);
				cout << "\n\n The error is : " << cError;
			}
		}
		else {
			EMH_ask_error_text(iFail, &cError);
			cout << "\n\n The error is : " << cError;
		}
	}
	else {
		EMH_ask_error_text(iFail, &cError);
		cout << "\n\n The error is : " << cError;
	}
	return iFail;

}